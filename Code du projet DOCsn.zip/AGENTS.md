<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture decisions
- Keep the mobile CV editor's form and A4 preview mounted behind a view switch, so switching views preserves edits and desktop/print keeps the shared document engine.

- Keep CV template definitions data-driven in `src/lib/resume.ts` and render their compositions through one printable A4 engine, so all variants retain identical editing and PDF behavior.
- Render every CV through the single shared preview/print engine with no ATS-only presentation mode, so decorative templates remain the one export path.
- Store compressed profile photos inside each locally persisted resume, so the open-access app remains account-free and portable within the current browser.
- Keep delivery invoices in their own localStorage store (`src/lib/invoice-store.ts`), separate from CVs, so the app stays account-free.
- Keep member cards in their own localStorage store (`src/lib/member-card-store.ts`), with auto-generated MBR-YYYY-NNNN numbers, so the app stays account-free.
- Render member-card backgrounds as scalable vector drawings shared by swatches, preview and print, so selected artwork stays identical and sharp at every size.
- Keep internship request letters in their own localStorage store (`src/lib/letter-store.ts`), with a pre-filled letter template, so the app stays account-free.
- Keep homepage document thumbnails presentational and independent of saved user documents, so examples never read or modify personal data.
- Public access: the shared document gate renders immediately without authentication, account links are not offered, and the legacy `/auth` URL redirects home, so every document tool works without an account.
- localStorage remains the source of truth and cloud sync stays unmounted, so existing browser documents are preserved without requiring or contacting an account.
- Accounts and cloud sync use the owner's own Supabase project via `src/lib/docsn-supabase.ts` (not the Lovable Cloud client), because the owner wants data in their own project while Cloud stays attached.
- Analytics are sent through one shared gtag loader in `src/lib/analytics.ts`, initialized once from the root route, so no duplicate Google tags are installed.

- Public sitemap pages declare self-referencing canonical and og:url values in their leaf route heads using the primary origin, so www and preview URLs do not compete in search.
