# Ouvrir DOCsn dans VS Code

Ce dossier contient tout le code du site **DOCsn** (https://docsn.app).

## 1. Installer Bun (une seule fois)

Bun sert à installer les modules et à lancer le site.

- **macOS / Linux** : `curl -fsSL https://bun.sh/install | bash`
- **Windows (PowerShell)** : `powershell -c "irm bun.sh/install.ps1 | iex"`

Vérifier : `bun --version`

## 2. Installer les modules

Ouvrir le dossier `DOCsn` dans VS Code, puis dans le terminal intégré (Ctrl+` ou Cmd+`) :

```bash
bun install
```

## 3. Lancer le site en local

```bash
bun run dev
```

Puis ouvrir **http://localhost:8080** dans le navigateur.

## 4. Autres commandes utiles

| Commande | Ce qu'elle fait |
| --- | --- |
| `bun run dev` | Site en local, changement visible tout de suite |
| `bun run build` | Préparation de la version à publier |
| `bun run preview` | Aperçu local de la version construite |
| `bun run test` | Lance les tests (3 fichiers dans `src/test`) |
| `bun run lint` | Vérifie la qualité du code |
| `bun run format` | Met en forme le code automatiquement |

## 5. Le fichier `.env`

Il contient uniquement des valeurs publiques (adresse du backend, clé publiable,
identifiant Google Analytics `G-5PGE2YLHP2`). Aucune clé secrète n'y figure.
Si vous déménagez le backend, remplacez `VITE_SUPABASE_URL`,
`VITE_SUPABASE_PUBLISHABLE_KEY` et `VITE_SUPABASE_PROJECT_ID`.

## 6. Où se trouve quoi

| Chemin | Contenu |
| --- | --- |
| `src/routes/` | Les pages du site (accueil, éditeur CV, factures, cartes, lettres, tableau de bord) |
| `src/lib/` | La logique : modèles de CV, enregistrement local, factures, cartes, lettres, statistiques |
| `src/components/` | Les morceaux d'interface, dont les composants `ui/` réutilisables |
| `src/assets/` | Logo et photos du site |
| `src/styles.css` | Les couleurs, polices et styles généraux |
| `src/integrations/supabase/` | Connexion au backend (générée automatiquement, ne pas modifier) |
| `drizzle/` | Le schéma et les migrations de la base de données |
| `supabase/config.toml` | Réglages du backend |

## 7. Point important

Les documents des visiteurs (CV, factures, cartes, lettres) sont enregistrés
**dans le navigateur** de chaque personne : aucun compte n'est demandé.
C'est le fichier `src/lib/store.ts` et les stores voisins qui gèrent cela.
